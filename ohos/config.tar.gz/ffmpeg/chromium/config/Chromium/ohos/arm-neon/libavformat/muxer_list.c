static const FFOutputFormat * const muxer_list[] = {
    NULL };
